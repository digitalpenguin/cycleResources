<?php
/**
 * Default English Lexicon Entries for cycleResources
 *
 * @package cycleresources
 * @subpackage lexicon
 */

$_lang['cycleresources'] = 'cycleResources';

